﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxLibrary
{
    /// <summary>
    /// Перечисление материалы для создания фигур
    /// </summary>
    public enum Material
    {
        Paper,
        Film
    }
}
