﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxLibrary
{
    /// <summary>
    /// Перечисление цветов
    /// </summary>
    public enum Color
    {
        Red,
        Green,
        Blue,
        Yellow,
        Gray,
        Purple,
        Pink,
        Black,
        White
    }
}
