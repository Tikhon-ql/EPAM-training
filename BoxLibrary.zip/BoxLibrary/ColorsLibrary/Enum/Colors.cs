﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ColorsLibrary
{
    /// <summary>
    /// Перечисление цветов
    /// </summary>
    public enum Colors
    {
        Red,
        Blue,
        Green,
        Yellow,
        Pink,
        Purple,
        Brown,
        White,
        Black
    }
}
