﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxLibrary
{
    public enum Color
    {
        Red,
        Green,
        Blue,
        Yellow,
        Gray,
        Purple,
        Pink,
        Black,
        White
    }
}
