﻿using Figures;
using Figures.Models;
using FileWork;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Part2
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
